fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'A-C SHOP'
description 'NPC REVIVE CUANDO NO HAY EMS DISPONIBLE'
version '1.0.0'

server_scripts {
    '@es_extended/locale.lua',
    'server.lua'
}

client_scripts {
    '@es_extended/locale.lua',
    'client.lua'
}

dependency '/assetpacks'